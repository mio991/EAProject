<?php
    session_start();
	require_once realpath('configure.inc.php');
	require_once realpath('functions.inc.php');
	require_once realpath('class/mysql.class.php');
?>